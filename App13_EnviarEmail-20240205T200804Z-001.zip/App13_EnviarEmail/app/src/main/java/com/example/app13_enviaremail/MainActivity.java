package com.example.app13_enviaremail;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("QueryPermissionsNeeded")
    public void enviarEmail(View vi) {

        EditText destinatario = findViewById(R.id.destinatario);
        EditText assunto = findViewById(R.id.assunto);
        EditText corpo = findViewById(R.id.corpo);

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto", String.valueOf(destinatario.getText()), null));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, String.valueOf(assunto.getText()));
        emailIntent.putExtra(Intent.EXTRA_TEXT, String.valueOf(corpo.getText()));
        startActivity(Intent.createChooser(emailIntent, "enviar_email"));

        /*EditText corpo = findViewById(R.id.corpo);
       // corpo.setAutofillHints(String.valueOf(View.IMPORTANT_FOR_AUTOFILL_AUTO));
        EditText assunto = findViewById(R.id.assunto);
       // assunto.setAutofillHints(String.valueOf(View.IMPORTANT_FOR_ACCESSIBILITY_AUTO));

        Intent intent = new Intent(Intent.ACTION_SENDTO);

        intent.setData(Uri.parse("mailto:adrianocesar01@gmail.com")).putExtra(Intent.EXTRA_SUBJECT, assunto.getText().toString()).putExtra(Intent.EXTRA_TEXT, corpo.getText().toString());

        if (intent.resolveActivity(getPackageManager()) != null) {
        startActivity(intent);

    }*/

    }
}