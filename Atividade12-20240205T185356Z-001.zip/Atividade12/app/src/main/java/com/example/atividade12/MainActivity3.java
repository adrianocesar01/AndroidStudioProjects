package com.example.atividade12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void Mineirao(View v){

        Intent mapIntent = new Intent(Intent.ACTION_VIEW);
        mapIntent.setData(Uri.parse("google.navigation:q=Estádio Mineirão BH&mode=d"));
        startActivity(mapIntent);

    }
    public void Voltar2( View v)
    {
        Intent tela1 = new Intent(MainActivity3.this, MainActivity.class);
        startActivity(tela1);
    }
}