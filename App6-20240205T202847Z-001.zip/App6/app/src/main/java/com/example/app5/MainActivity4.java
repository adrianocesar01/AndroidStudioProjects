package com.example.app5;

//Na quarta tela ( telaDiscagem)
//        Incluir um campo de entrada para informar o telefone.
//        Um botão para Realizar a discagem

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity4 extends AppCompatActivity {

    private EditText edtelefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        edtelefone = findViewById(R.id.editTextPhone);
    }

    @SuppressLint("QueryPermissionsNeeded")
    public void Ligar(View V) {

//1 - Instancia um Intent do tipo Dialog para realizar chamadas
        Intent myIntent = new Intent(Intent.ACTION_DIAL);

        // 2- Instancia o objetivo edtelefone
        edtelefone = findViewById(R.id.editTextPhone);

//3 -Recupera o telefone digitado
        String telefone = edtelefone.getText().toString();

//4 - Adiciona como parametro o telefone informado dentro da Intent
        myIntent.setData(Uri.parse("tel:" + telefone));

//5 - Verifica se existe um aplicativo de discagem antes de chamar a intent.
//        if (myIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(myIntent);

       // }
    }

    public void TelaPrincipal(View v){
        Intent myIntent2 = new Intent(MainActivity4.this,MainActivity2.class);

        startActivity(myIntent2);
    }
}