package com.example.app5;

//Terceira tela ( telaCalculoCaloria)

//        Incluir um campo de entrada para informar quantas horas gastou na esteira.
//        Deixar como fixo o 150 caloria/hora para realizar o calculo ( usar somente no código)
//        Ter campo para ter a saída do consumo geral de caloria gerada ( 150 x qte horas gasta na esteira)
//        Ter um botão para executar a ação.
//        Ter um botão para voltar para a tela inicial.

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edNum1;
    private TextView textResultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNum1 = findViewById(R.id.edNum1);
        textResultado = findViewById(R.id.textResultado);
    }

    public void Calcular(View v){
        int t1 = edNum1.length();

        if(t1 > 0){

            int num1 = Integer.parseInt(edNum1.getText().toString());
            int hrsEsteira = (num1 * 150);

            textResultado.setText(getString(R.string.stringResult,
                    Integer.toString(hrsEsteira),
                    Integer.toString(num1)
            ));
        }
        else {
            textResultado.setText(getString(R.string.stringResultInvalid));
        }
    }
    public void TelaPrincipal(View v){
        Intent myIntent = new Intent(MainActivity.this,MainActivity2.class);

        startActivity(myIntent);
    }
}