package com.example.app5;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edNum1;
    private EditText edNum2;
    private EditText edNum3;
    private EditText edNum4;
    private TextView textResultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNum1 = findViewById(R.id.edNum1);
        edNum2 = findViewById(R.id.edNum2);
        edNum3 = findViewById(R.id.edNum3);
        edNum4 = findViewById(R.id.edNum4);
        textResultado = findViewById(R.id.textResultado);
    }

    public void Calcular(View v){
        int t1 = edNum1.length();
        int t2 = edNum2.length();
        int t3 = edNum3.length();
        int t4 = edNum4.length();

        if((t1 > 0) && (t2 > 0) && (t3 > 0) && (t4 > 0)) {

            int num1 = Integer.parseInt(edNum1.getText().toString());
            int ovo = (num1 * 15);
            int num2 = Integer.parseInt(edNum2.getText().toString());
            int arroz = (num2 * 3);
            int num3 = Integer.parseInt(edNum3.getText().toString());
            int carne = (num3 * 50);
            int num4 = Integer.parseInt(edNum4.getText().toString());
            int morango = (num4 * 15);
            int result = ((ovo)+(arroz)+(carne)+(morango));
            textResultado.setText(getString(R.string.stringResult,
                    Integer.toString(result),
                    Integer.toString(ovo),
                    Integer.toString(arroz),
                    Integer.toString(carne),
                    Integer.toString(morango)
            ));
        }
        else {
            int result = 0;
            textResultado.setText(getString(R.string.stringResultInvalid, Integer.toString(result)));
        }
    }
}