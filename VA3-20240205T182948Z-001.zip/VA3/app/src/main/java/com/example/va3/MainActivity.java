package com.example.va3;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textResult;
    private EditText quantQuartos;
    private EditText quantGaragens;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textResult = findViewById(R.id.textView);
        quantQuartos = findViewById(R.id.editTextQuartos);
        quantGaragens = findViewById(R.id.editTextGaragens);

    }

        public void Calcular (View v){

        try {
            double quantidadeQuartos = Double.parseDouble(quantQuartos.getText().toString());
            double quantidadeGaragens = Double.parseDouble(quantGaragens.getText().toString());

            if (quantidadeQuartos >= 1 && quantidadeGaragens >= 1) {

                double totalQuartos = (quantidadeQuartos * 11500);
                double totalGaragens = (quantidadeGaragens * 20000);
                double resultado = (totalQuartos + totalGaragens);

                textResult.setText(getString(R.string.resultadoValido, Double.toString(resultado)));
            } else {
                textResult.setText(getString(R.string.resultadoInvalido));
            }

        }catch(Exception error1){

                Log.e(TAG, "A exceção capturada durante a execução do processo. (error1)");
                error1.printStackTrace();}
    }

    public void Limpar(View v){

        quantQuartos.getText().clear();
        quantGaragens.getText().clear();
        textResult.setText(getString(R.string.resultado));
    }
}