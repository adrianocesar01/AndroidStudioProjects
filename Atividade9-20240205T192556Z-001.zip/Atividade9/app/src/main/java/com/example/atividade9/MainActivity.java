package com.example.atividade9;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
//import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

//    private WebView view1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        view1 = findViewById(R.id.view1);
    }

    @SuppressLint("QueryPermissionsNeeded")
    public void Navegar(View v){

        Intent mapIntent = new Intent(Intent.ACTION_VIEW);

        mapIntent.setData(Uri.parse("google.navigation:q=Faculdade Promove Prado&mode=d&origin=Centro BH"));

//        if (mapIntent.resolveActivity(getPackageManager()) != null) {
//            System.out.println("If!");
//            startActivity(mapIntent);
//        }
//        else{
//            System.out.println("Else!");
            startActivity(mapIntent);
//        }

//        Tipos de mode:
//        d – drive
//        w – walk
//        b - bike

        // documentação
        // https://developers.google.com/maps/documentation/urls/get-started?hl=pt-br



    }
}