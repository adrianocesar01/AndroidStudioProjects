package com.example.va2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Pessoa1(View v) {
        Intent myIntent1 = new Intent(MainActivity.this, MainActivity2.class);

        startActivity(myIntent1);
    }

    public void Pessoa2(View v) {
        Intent myIntent2 = new Intent(MainActivity.this, MainActivity3.class);

        startActivity(myIntent2);
    }

    public void Pessoa3(View v) {
        Intent myIntent3 = new Intent(MainActivity.this, MainActivity4.class);

        startActivity(myIntent3);
    }

    public void Pessoa4(View v) {
        Intent myIntent4 = new Intent(MainActivity.this, MainActivity5.class);

        startActivity(myIntent4);
    }

    public void Pessoa5(View v) {
        Intent myIntent5 = new Intent(MainActivity.this, MainActivity6.class);

        startActivity(myIntent5);
    }

    public void Pessoa6(View v) {
        Intent myIntent6 = new Intent(MainActivity.this, MainActivity7.class);

        startActivity(myIntent6);
    }
}