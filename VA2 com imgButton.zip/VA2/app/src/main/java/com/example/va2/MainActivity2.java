package com.example.va2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    @SuppressLint("QueryPermissionsNeeded")
    public void Ligar(View V) {

        Intent myIntent = new Intent(Intent.ACTION_DIAL);

        String tel = "31987291850";

        myIntent.setData(Uri.parse("tel:" + tel));

        startActivity(myIntent);

    }

    public void TelaPrincipal(View v){
        Intent myIntent = new Intent(MainActivity2.this, MainActivity.class);

        startActivity(myIntent);
    }
}