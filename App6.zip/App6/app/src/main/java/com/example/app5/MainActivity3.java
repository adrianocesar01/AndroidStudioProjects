package com.example.app5;

//Segunda tela ( telaCalculoIMC)
//        Incluir dois campos de entrada para Peso e altura.
//        Ter um campo para ter a saída do cálculo do IMC.
//        Incluir um botão para executar a ação de cálculo e outro botão para voltar para a primeira tela (telaPrincipal)

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    private EditText peso;
    private EditText altura;
    private TextView iMC;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        peso = findViewById(R.id.peso);
        altura = findViewById(R.id.altura);
        iMC = findViewById(R.id.iMC);
    }
    public void CalcularIMC(View v) {
        try {
            double peso1 = Double.parseDouble(peso.getText().toString());
            double altura1 = Double.parseDouble(altura.getText().toString());
            double iMC1 = (peso1 / (altura1 * altura1));
            iMC.setText(getString(R.string.stringResultIMC, Double.toString(iMC1)));
        }catch (NumberFormatException error){
            iMC.setText(getString(R.string.stringResultInvalid));
        }
        }


    public void TelaPrincipal(View v){
        Intent myIntent = new Intent(MainActivity3.this,MainActivity2.class);

        startActivity(myIntent);
    }
}