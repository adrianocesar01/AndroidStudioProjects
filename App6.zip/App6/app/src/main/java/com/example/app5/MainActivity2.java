package com.example.app5;

//Tela Principal: Ter dois botões. Um escrito CalcularIMC e o outro Calcular Caloria

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void RetornarIMC(View v){
        Intent myIntent = new Intent(MainActivity2.this,MainActivity3.class);

        startActivity(myIntent);
    }
    public void RetornarCalcCaloria(View v){
        Intent myIntent2 = new Intent(MainActivity2.this,MainActivity.class);

        startActivity(myIntent2);
    }

    public void Ligar(View v){
        Intent myIntent3 = new Intent(MainActivity2.this,MainActivity4.class);

        startActivity(myIntent3);
    }
}